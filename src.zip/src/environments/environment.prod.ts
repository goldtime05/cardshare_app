export const environment = {
  production: true,
  config : {
      apiKey: "AIzaSyCyE8R8e33aXIeFFMRp_bOvHH3L3OaiN24",
      authDomain: "cardnew-a842e.firebaseapp.com",
      databaseURL: "https://cardnew-a842e.firebaseio.com",
      projectId: "cardnew-a842e",
      storageBucket: "cardnew-a842e.appspot.com",
      messagingSenderId: "284371336752",
      appId: "1:284371336752:web:8ad6ef03264534eef937f5",
      measurementId: "G-XSSRWS9G0N"
  }
};
